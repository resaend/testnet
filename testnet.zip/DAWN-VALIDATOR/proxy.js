module.exports = [
    'http://proxy1:port',
    'http://proxy2:port',
    'proxy:port',
    'https://user:pass@proxy:port',
	// change all this with your proxy if you want to use proxy
];
